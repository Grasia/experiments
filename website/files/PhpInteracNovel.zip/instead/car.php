<?php include "header.php" ?>

<p> La fiesta ha comenzado. La gente se lo está pasando bien. Puedes oir música y hay mucha gente bailando. </p>

<p> De repente ves a dos personas totalmente borrachas. El conductor se le nota que va borracho por sus ojos, su copa en la mano, y por su canturreo casi indescifrable. Eres consciente de que es un peligro para todos pero no sabes cómo enfrentarte al problema. </p>

<p>
Empiezas a soñar que estás en una ciudad inteligente. Se te ocurren varias opciones. Sacas tu móvil y entras en tu <a href="app1.php?factor=interactionMechanism&msg=app"> app Evita Un Accidente</a>, o apretas a un botón con dos copas en un <a href="semaforo.php?factor=interactionMechanism&msg=trafficLight"> semáforo inteligente </a> o, simplemente, <a href="gesto.php?factor=interactionMechanism&msg=handGesture">señalas con tu mano </a> al coche.
</p>



<?php include "footer.php" ?>