<?php include "header.php" ?>

<?php add("authorities") ?>

<p> La app te confirma que que las autoridades están en camino. </p>

<p> Por un lado te da <a href="fin.php?factor=authorities&msg=autohoritiesNotFastEnough"> miedo </a> que haya un accidente antes de que lleguen las autoridades, pero por otro lado te quedas tranquilo de que has hecho lo correcto y de que es la única <a href="fin.php?factor=authorities&msg=authoritiesFine"> manera sensata de gestionarlo </a>. </p>
<?php include "footer.php" ?> 