<?php include "header.php" ?>
<p> El semáforo se pone en rojo y suena por el altavoz "Por favor, al conductor del vehículo rojo de marca Ford, con matrícula 123456X, le rogamos que estacione su vehículo lo antes posible si ha ingerido alcohol. Si es vuelto a ser denunciado en otro de nuestros semáforos, las autoridades pertinentes le localizarán para examinar su estado." </p>

<p> Por un lado, te <a href="./miedo.php?factor=trafficLightAloudWarning&msg=OkTrafficLightFunctioning"> parece bien </a> que el semáforo actúe así, pero por otro lado <a href="./miedo.php?factor=trafficLightAloudWarning&msg=NotOkTrafficLightFunctioning"> NO es del todo práctico </a> considerando el flujo global del tráfico</p>

<?php include "footer.php" ?>