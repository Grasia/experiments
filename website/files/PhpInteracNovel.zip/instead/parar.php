<?php include "header.php" ?>
<p> El vehículo con las personas borrachas se para lentamente y pone las luces de emergencia, en contra de la voluntad de su conductor. </p>

<p>Las dos personas borrachas salen del vehículo gritando y con cara de violento. Se queda bloqueada uno de los dos carriles de la avenida complutense. Los coches esquivan al coche parado. </p>

<p> <a href="miedo.php"> Siguiente >> </a>
<?php include "footer.php" ?>

