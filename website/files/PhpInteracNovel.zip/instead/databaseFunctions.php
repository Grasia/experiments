<?php 
// Constants
/*
// XAMPP login data
define("DB_NAME", "instead");
define("SERVERNAME","localhost");
define("USERNAME", "root");
define("PASSWORD", "");
/*/
// Infinity login data (for deployment in website http://igarciam.epizy.com/instead/)
define("DB_NAME", "epiz_24853845_instead");
define("SERVERNAME","sql308.epizy.com");
define("USERNAME", "epiz_24853845");
define("PASSWORD", "fCWbUISj6zvsazL");
//*/

// Testing 
//storeEventInDB("test","3");
//storeUrlParamsInDB();

// It executes a SQL query
function execQuery($sql){
	
	// Create connection
	$conn = new mysqli(SERVERNAME, USERNAME, PASSWORD);
	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}

	// Execute Query
	//$sql = "CREATE DATABASE instead";
	//$sql = "USE ".$database."; ".$sql;
	if ($conn->query($sql) === TRUE) {
	    echo ""; //None // "Successful execution of ". $sql;
	} else {
	    echo "Error executing " . $sql . " with error ". $conn->error;
	}

	$conn->close();
}

// It stores a factor and an option in the database
function storeEventInDB($factor, $msg){
	$sql = "INSERT INTO ".DB_NAME.".events VALUES (now(), '". $factor."' , '".$msg."');";
	execQuery($sql);
}

// It stores an event from the get parameters "factor" (if any) and "msg"
function storeUrlParamsInDB(){
	$factor = "none";
	if(!empty ($_GET["factor"]))
		$factor = $_GET["factor"];
	if(!empty($_GET["msg"])){
		$msg = $_GET["msg"];
		storeEventInDB($factor, $msg);
	}
}
?>
