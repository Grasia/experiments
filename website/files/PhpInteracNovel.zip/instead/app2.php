<?php include "header.php" ?>
<p> La app Evita un Accidente tiene la posibilidad de <a href="parar.php?factor=appAction&msg=stopVehicle"> parar el vehiculo</a> o de <a href="alertar.php?factor=appAction&msg=warnAuthorities"> aletar a las autoridades. </a> </p>
<?php include "footer.php" ?>