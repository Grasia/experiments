<?php include "header.php" ?>
<p> Al señalar con el dedo, la ciudad detecta tu gesto, se comunica con el coche y lo para lentamente para evitar accidentes </p>

<p> <a href="miedo.php"> Siguiente >> </a> </p>
<?php include "footer.php" ?>