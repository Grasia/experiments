<?php include "header.php" ?>

<p> Se abre la nueva app para evitar accidentes en tu ciudad inteligente. </p>

<p> En la app, se puede <a href="app2.php?factor=wayOfScanning&msg=scanNumberPlate"> enfocar a la matrícula </a> o simplemente <a href="app2.php?factor=wayOfScanning&msg=pointWithPhone">señalar con el móvil</a>. </p>



<?php include "footer.php" ?>