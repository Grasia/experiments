<?php include "header.php" ?>
<p> Muchas gracias por haber jugado a este juego. Tu juego nos ayudará a construir la ciudad inteligente que todos deseamos. </p>

<p> <a href="car.php?msg=restart"> Volver a empezar? </a> </p>

<?php includeOptionLogs() ?>

<?php include "footer.php" ?>