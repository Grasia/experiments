<?php include "header.php" ?>


<p> En este juego, vas a jugar leyendo una aventura, en la que pulsarás en las palabras resaltadas que más reflejen tus sensaciones, acciones que tomarías, u opiniones. Leélo todo antes de elegir qué pulsar dado que la mayoría de veces que hagas click en un enlace se te llevará a alguna pantalla diferente del juego. </p>

<p> <a href="./car.php?msg=begin"> Start the game </a> </p>

<?php includeOptionLogs() ?>

<?php include "footer.php" ?>