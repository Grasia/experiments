<html>
<head>
<title>Smart cities</title>
<meta charset="UTF-8">
<meta name="description" content="Homepage of Iv&aacute;n Garc&iacute;a-Magari&ntilde;o"/>
<meta name="keywords" content="García-Magariño,Iván,Multi-agent system,model-driven engineering,simulation"/>
<meta name="author" content="Iván García-Magariño"/>
<!--LINK REL=StyleSheet HREF="./style.css" TYPE="text/css"/-->
</head>
<body>
<header>
<h1> Evitando el peligro al volante con ciudad inteligente </h1>
</header>
<nav>
</nav>



<?php include 'mainFunctions.php' ?>
<?php include 'databaseFunctions.php' ?>

<?php
// Add the message of the "get" parameter to the log if any

if(!empty($_GET["msg"])){
	$msg = $_GET["msg"];
	if ($msg !=null){
		add($msg);
	}
}

// Add factor (if any) and msg to the database
storeUrlParamsInDB();
?>

<div class = "content">
<section>

<h1> Avenida de Ciudad Universitaria </h1>