<?php include "header.php" ?>


<p> Por un lado, te da <a href="./fin.php?factor=driverStepsOut&msg=scareOfDrivers"> miedo </a> que los borrachos se enfaden contigo y corras peligro </p>

<p> Por otro lado, te alegras porque te da la <a href="./fin.php?factor=driverStepsOut&msg=possibilityToExplain"> posibilidad de explicarle </a> a los borrachos de que es mejor no conducir en estado porque es e un peligro para los demás. </p>
<?php include "footer.php" ?>
