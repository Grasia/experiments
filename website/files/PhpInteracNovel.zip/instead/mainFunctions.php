<?php 
// Constants
define ("DATA_PATH", '../insteadData/data.txt');

// It stores a message with its timestamp
function add($msg){
	$fecha = new DateTime();
	$row = $fecha->getTimestamp()."\t".$msg."</br>\n";
	$filename = DATA_PATH;
	if(file_exists($filename)){
		$fp = fopen($filename, 'a+') or die ("Unable to open the file");
		if(!(fwrite ($fp, $row))){
			echo("Error while writing on the file");
		}
		fclose ($fp);
	}
}

//  Includes the option to see the logs
function includeOptionLogs(){
	$uriParts = explode('?', $_SERVER['REQUEST_URI'], 2);
	$selfUrl = $uriParts[0];
	if(!empty($_GET["logs"])){ // !=null
		echo ' <p> <a href="'. $selfUrl.'"> Hide the logs </a> </p>';
		echo "<h1> All Data Saved Until Now </h1>";
		include DATA_PATH;
	}else{
		echo ' <p> <a href="'. $selfUrl.'?logs=ok"> See the logs </a> </p>';
	}
}


?>
